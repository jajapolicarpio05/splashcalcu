package com.policarpio.splashcalcu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    double fNum = 0;
    double sNum = 0;
    double result = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
public void insert(){
    EditText  one = (EditText) findViewById(R.id.fNum);
    EditText  two = (EditText) findViewById(R.id.sNum);
    fNum = Double.parseDouble(one.getText().toString());
    sNum =Double.parseDouble(two.getText().toString());
}
public void convertAndAppend() {
    EditText ret = (EditText) findViewById(R.id.result);
    ret.setText(Double.toString(result));
}
    public void add (View v){
        try{
            insert();
            result = fNum + sNum ;
            convertAndAppend();
        }catch (NumberFormatException e){
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("ERROR");

        }catch (ArithmeticException e) {
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("MATH ERROR");
        }
    }

    public void minus (View v){
        try{
            insert();
            result = fNum - sNum;
            convertAndAppend();
        }catch (NumberFormatException e){
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("ERROR");

        }catch (ArithmeticException e) {
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("MATH ERROR");
        }
    }

    public void multi (View v){
        try{
            insert();
            result = fNum * sNum;
            convertAndAppend();
        }catch (NumberFormatException e){
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("ERROR");

        }catch (ArithmeticException e) {
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("MATH ERROR");
        }
    }

    public void div (View v){
        try{
            insert();
            result = fNum / sNum;
            convertAndAppend();
        }catch (NumberFormatException e){
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("ERROR");

        }catch (ArithmeticException e) {
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("MATH ERROR");
        }
    }

    public void modulo (View v){
        try{
            insert();
            result = fNum % sNum;
            convertAndAppend();
        }catch (NumberFormatException e){
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("ERROR");

        }catch (ArithmeticException e) {
            EditText err = (EditText) findViewById(R.id.result);
            err.setText("MATH ERROR");
        }
    }

    public void clear (View v) {
        EditText clear = (EditText) findViewById(R.id.result);
        EditText one = (EditText) findViewById(R.id.fNum);
        EditText two = (EditText) findViewById(R.id.sNum);
        clear.setText("");
        clear.setText("");
        clear.setText("");

    }

}


















